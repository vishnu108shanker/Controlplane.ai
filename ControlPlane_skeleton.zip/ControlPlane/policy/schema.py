"""
policy/schema.py

Architecture component: Policy compilation (architecture.md §3, deterministic).

Typed representation of the policy JSON object defined in architecture.md §6.
This is the single source of truth for what a "policy" is in this codebase --
runtime/evaluator.py, engine/discover.py's output, and api/main.py should all
import and use these types rather than passing around raw dicts.

STATUS: stub. Fields and shape are fixed by architecture.md §6 -- do not redesign
the schema, only implement the validation/(de)serialization behavior.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Literal


class Operator(str, Enum):
    EQ = "=="
    NEQ = "!="
    LTE = "<="
    GTE = ">="
    LT = "<"
    GT = ">"
    IN = "in"


class Action(str, Enum):
    AUTO_PROCESS = "AUTO_PROCESS"
    HUMAN_REVIEW = "HUMAN_REVIEW"


class PolicyStatus(str, Enum):
    DRAFT = "draft"
    PROPOSED = "proposed"
    APPROVED = "approved"
    REJECTED = "rejected"
    ACTIVE = "active"
    SUPERSEDED = "superseded"


@dataclass
class Condition:
    field: str
    operator: Operator
    value: Any

    def evaluate(self, claim: dict) -> bool:
        """
        Evaluate this single condition against a claim dict.

        TODO: implement comparison logic for each Operator value.
        `field` must match a real column name in data/insurance_claims.csv --
        see docs/conventions.md "Policy object conventions".
        """
        raise NotImplementedError


@dataclass
class Evidence:
    train_support: int
    train_success_rate: float
    train_lift: float
    train_p_value: float
    held_out_support: int
    held_out_success_rate: float
    held_out_baseline_success_rate: float
    naive_threshold_success_rate: float


@dataclass
class Policy:
    policy_id: str
    supersedes: str | None
    conditions: list[Condition]
    action: Action
    requires_human: bool
    evidence: Evidence | None  # None only allowed for hand-authored baseline (v1)
    rationale: str
    status: PolicyStatus

    def matches(self, claim: dict) -> bool:
        """
        A claim matches this policy if ALL conditions evaluate True (conjunction).

        TODO: implement. See docs/architecture.md §6 for the exact JSON shape
        this must round-trip to/from.
        """
        raise NotImplementedError

    @classmethod
    def from_json_file(cls, path: str) -> "Policy":
        """TODO: load + validate a policy JSON file (e.g. policy/versions/POLICY-042-v1.json)."""
        raise NotImplementedError

    def to_json_file(self, path: str) -> None:
        """TODO: serialize this policy to disk. Never overwrite an existing version file --
        see docs/conventions.md "Policy object conventions"."""
        raise NotImplementedError
